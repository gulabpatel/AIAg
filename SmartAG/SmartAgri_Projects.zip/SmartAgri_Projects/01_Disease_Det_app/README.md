![](https://github.com/gulabpatel/AIAg/blob/main/SmartAG/AugmentedStartupCourse/01_Disease_Det_app/Disease_det_demo.PNG)
