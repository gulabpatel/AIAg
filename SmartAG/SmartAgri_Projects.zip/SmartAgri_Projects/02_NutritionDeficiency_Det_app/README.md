![](https://github.com/gulabpatel/AIAg/blob/main/SmartAG/AugmentedStartupCourse/02_NutritionDeficiency_Det_app/Nutrition_Def.PNG)

![](https://github.com/gulabpatel/AIAg/blob/main/SmartAG/AugmentedStartupCourse/02_NutritionDeficiency_Det_app/Nutrition_Def2.PNG)
