
## Crop recommender 

https://github.com/gulabpatel/AIAg/assets/62597299/11bf976e-3c2b-45fc-b3c6-ff3e4beea346
